package com.ktds.soowoo.market.company.biz;

public interface CompanyBiz {

}
