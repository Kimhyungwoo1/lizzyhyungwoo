package com.ktds.soowoo.market.drink.biz;

public interface DrinkBiz {

}
