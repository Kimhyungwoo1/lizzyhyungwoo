package com.ktds.soowoo.market.drink.vo;

public class DrinkVO {

}
