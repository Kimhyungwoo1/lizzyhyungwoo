package com.ktds.soowoo.market.user.biz;

public interface UserBiz {

}
