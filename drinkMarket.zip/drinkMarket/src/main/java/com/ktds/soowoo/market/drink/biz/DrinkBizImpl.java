package com.ktds.soowoo.market.drink.biz;

public class DrinkBizImpl {

}
