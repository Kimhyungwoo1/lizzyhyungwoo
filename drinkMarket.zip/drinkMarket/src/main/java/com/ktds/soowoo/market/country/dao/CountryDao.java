package com.ktds.soowoo.market.country.dao;

public interface CountryDao {

}
