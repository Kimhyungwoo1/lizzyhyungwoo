package com.ktds.soowoo.market.user.vo;

public class UserVO {

}
