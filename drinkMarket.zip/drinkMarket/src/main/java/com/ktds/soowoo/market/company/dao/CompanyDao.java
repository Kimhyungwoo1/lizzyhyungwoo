package com.ktds.soowoo.market.company.dao;

public interface CompanyDao {

}
