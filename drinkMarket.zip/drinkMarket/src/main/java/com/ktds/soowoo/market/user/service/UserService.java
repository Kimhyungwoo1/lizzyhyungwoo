package com.ktds.soowoo.market.user.service;

public interface UserService {

}
