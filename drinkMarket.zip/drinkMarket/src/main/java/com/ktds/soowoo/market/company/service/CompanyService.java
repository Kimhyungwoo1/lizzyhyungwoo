package com.ktds.soowoo.market.company.service;

public interface CompanyService {

}
