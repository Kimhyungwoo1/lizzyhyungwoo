package com.ktds.soowoo.market.user.dao;

public interface UserDao {

}
