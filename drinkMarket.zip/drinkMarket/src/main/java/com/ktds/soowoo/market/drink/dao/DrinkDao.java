package com.ktds.soowoo.market.drink.dao;

public interface DrinkDao {

}
