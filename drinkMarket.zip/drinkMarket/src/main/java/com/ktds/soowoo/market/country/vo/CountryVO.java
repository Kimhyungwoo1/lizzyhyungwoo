package com.ktds.soowoo.market.country.vo;

public class CountryVO {

}
