package com.ktds.soowoo.market.country.biz;

public interface CountryBiz {

}
