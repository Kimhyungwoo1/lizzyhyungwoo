package com.ktds.soowoo.market.drink.service;

public interface DrinkService {

}
