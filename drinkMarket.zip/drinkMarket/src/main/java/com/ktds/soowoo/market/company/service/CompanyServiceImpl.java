package com.ktds.soowoo.market.company.service;

public class CompanyServiceImpl {

}
