package com.ktds.soowoo.market.company.vo;

public class CompanyVO {
	
	

}
