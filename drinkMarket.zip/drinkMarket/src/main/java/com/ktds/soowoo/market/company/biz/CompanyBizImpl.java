package com.ktds.soowoo.market.company.biz;

public class CompanyBizImpl {

}
