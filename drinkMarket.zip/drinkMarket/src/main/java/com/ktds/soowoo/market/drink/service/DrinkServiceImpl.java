package com.ktds.soowoo.market.drink.service;

public class DrinkServiceImpl {

}
